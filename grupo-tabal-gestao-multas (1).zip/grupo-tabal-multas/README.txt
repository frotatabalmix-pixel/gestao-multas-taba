GRUPO TABAL – GESTÃO DE MULTAS — versão inicial

Publicar index.html e app.js em hospedagem HTTPS (por exemplo GitHub Pages).
No Supabase Authentication, permitir e-mail/senha e cadastrar tabalmixmanutencao@gmail.com pela tela de acesso.
Depois da confirmação de e-mail, ativar perfil com SQL no projeto vtsdtyxhjdjepqycrpwm:
insert into public.perfis(user_id,nome,papel) select id,'Administrador Grupo Tabal','admin' from auth.users where email='tabalmixmanutencao@gmail.com' on conflict(user_id) do update set papel='admin',ativo=true;

O acesso sem perfil está bloqueado por RLS. A chave do aplicativo é pública; nenhuma chave secreta foi incluída.
Leitura inicial de PDFs com texto selecionável. PDFs digitalizados exigem OCR ainda não implementado.
Os termos de RH são impressos/salvos via navegador. Não aplicam desconto automaticamente.
O fluxo completo de aprovação da Diretoria e testes ponta a ponta ainda precisam ser concluídos.
